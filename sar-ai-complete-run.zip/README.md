# SAR-AI Dashboard

This is the complete version ready to run.
